<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
{
    if (!Schema::hasTable('keranjangs')) {
        Schema::create('keranjangs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('produk_id')->constrained('produks')->cascadeOnDelete();
            $table->integer('jumlah')->default(1);
            $table->timestamps();
        });
    } else {
        Schema::table('keranjangs', function (Blueprint $table) {
            if (!Schema::hasColumn('keranjangs', 'user_id'))
                $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            if (!Schema::hasColumn('keranjangs', 'produk_id'))
                $table->foreignId('produk_id')->constrained('produks')->cascadeOnDelete();
            if (!Schema::hasColumn('keranjangs', 'jumlah'))
                $table->integer('jumlah')->default(1);
        });
    }
}

    public function down(): void
    {
        Schema::dropIfExists('keranjangs');
    }
};