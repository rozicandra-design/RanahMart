<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
{
    Schema::table('tokos', function (Blueprint $table) {
        $table->date('tanggal_sertifikat')->nullable()->after('terverifikasi_dinas');
        $table->date('kadaluarsa_sertifikat')->nullable()->after('tanggal_sertifikat');
    });
}

public function down(): void
{
    Schema::table('tokos', function (Blueprint $table) {
        $table->dropColumn(['tanggal_sertifikat', 'kadaluarsa_sertifikat']);
    });
}
};
