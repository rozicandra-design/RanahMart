<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('produks', function (Blueprint $table) {
            if (!Schema::hasColumn('produks', 'toko_id')) {
                $table->foreignId('toko_id')->nullable()->constrained('tokos')->nullOnDelete();
            }
            if (!Schema::hasColumn('produks', 'total_terjual')) {
                $table->unsignedInteger('total_terjual')->default(0);
            }
            if (!Schema::hasColumn('produks', 'slug')) {
                $table->string('slug')->nullable();
            }
            if (!Schema::hasColumn('produks', 'harga_coret')) {
                $table->decimal('harga_coret', 12, 2)->nullable();
            }
            if (!Schema::hasColumn('produks', 'berat')) {
                $table->unsignedInteger('berat')->nullable()->comment('gram');
            }
            if (!Schema::hasColumn('produks', 'deleted_at')) {
                $table->softDeletes();
            }
        });
    }

    public function down(): void
    {
        Schema::table('produks', function (Blueprint $table) {
            if (Schema::hasColumn('produks', 'toko_id')) {
                $table->dropForeign(['toko_id']);
                $table->dropColumn('toko_id');
            }
            if (Schema::hasColumn('produks', 'total_terjual')) {
                $table->dropColumn('total_terjual');
            }
            if (Schema::hasColumn('produks', 'slug')) {
                $table->dropColumn('slug');
            }
            if (Schema::hasColumn('produks', 'harga_coret')) {
                $table->dropColumn('harga_coret');
            }
            if (Schema::hasColumn('produks', 'berat')) {
                $table->dropColumn('berat');
            }
            if (Schema::hasColumn('produks', 'deleted_at')) {
                $table->dropSoftDeletes();
            }
        });
    }
};