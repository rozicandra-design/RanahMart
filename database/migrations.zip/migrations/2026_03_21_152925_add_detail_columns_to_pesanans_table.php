<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('pesanans', function (Blueprint $table) {
            if (!Schema::hasColumn('pesanans', 'toko_id')) {
                $table->foreignId('toko_id')->constrained('tokos')->cascadeOnDelete();
            }
            if (!Schema::hasColumn('pesanans', 'user_id')) {
                $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            }
            if (!Schema::hasColumn('pesanans', 'kode_pesanan')) {
                $table->string('kode_pesanan')->unique()->nullable();
            }
            if (!Schema::hasColumn('pesanans', 'status_pesanan')) {
                $table->string('status_pesanan')->default('menunggu');
            }
            if (!Schema::hasColumn('pesanans', 'status_bayar')) {
                $table->string('status_bayar')->default('belum_bayar');
            }
            if (!Schema::hasColumn('pesanans', 'total')) {
                $table->decimal('total', 12, 2)->default(0);
            }
            if (!Schema::hasColumn('pesanans', 'ongkos_kirim')) {
                $table->decimal('ongkos_kirim', 12, 2)->default(0);
            }
            if (!Schema::hasColumn('pesanans', 'metode_pembayaran')) {
                $table->string('metode_pembayaran')->nullable();
            }
            if (!Schema::hasColumn('pesanans', 'alamat_pengiriman')) {
                $table->text('alamat_pengiriman')->nullable();
            }
            if (!Schema::hasColumn('pesanans', 'kurir')) {
                $table->string('kurir')->nullable();
            }
            if (!Schema::hasColumn('pesanans', 'no_resi')) {
                $table->string('no_resi')->nullable();
            }
            if (!Schema::hasColumn('pesanans', 'catatan')) {
                $table->text('catatan')->nullable();
            }
            if (!Schema::hasColumn('pesanans', 'dibayar_at')) {
                $table->timestamp('dibayar_at')->nullable();
            }
            if (!Schema::hasColumn('pesanans', 'dikirim_at')) {
                $table->timestamp('dikirim_at')->nullable();
            }
            if (!Schema::hasColumn('pesanans', 'selesai_at')) {
                $table->timestamp('selesai_at')->nullable();
            }
            if (!Schema::hasColumn('pesanans', 'deleted_at')) {
                $table->softDeletes();
            }
        });
    }

    public function down(): void
    {
        Schema::table('pesanans', function (Blueprint $table) {
            $table->dropColumn([
                'toko_id', 'user_id', 'kode_pesanan', 'status_pesanan',
                'status_bayar', 'total', 'ongkos_kirim', 'metode_pembayaran',
                'alamat_pengiriman', 'kurir', 'no_resi', 'catatan',
                'dibayar_at', 'dikirim_at', 'selesai_at', 'deleted_at',
            ]);
        });
    }
};