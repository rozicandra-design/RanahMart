<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
{
    Schema::table('transaksis', function (Blueprint $table) {
        $table->foreignId('user_id')->constrained()->cascadeOnDelete();
        $table->foreignId('toko_id')->nullable()->constrained()->nullOnDelete();
        $table->string('kode')->unique();
        $table->decimal('total', 12, 2)->default(0);
        $table->decimal('ongkir', 12, 2)->default(0);
        $table->decimal('diskon', 12, 2)->default(0);
        $table->enum('status', ['pending','dikonfirmasi','dikirim','selesai','dibatalkan'])->default('pending');
        $table->string('metode_bayar')->nullable();
        $table->timestamp('dibayar_at')->nullable();
    });
}

public function down(): void
{
    Schema::table('transaksis', function (Blueprint $table) {
        $table->dropColumn(['user_id','toko_id','kode','total','ongkir','diskon','status','metode_bayar','dibayar_at']);
    });
}
};
