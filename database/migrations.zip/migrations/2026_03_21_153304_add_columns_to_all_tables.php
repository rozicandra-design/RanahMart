<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // KERANJANGS
        Schema::table('keranjangs', function (Blueprint $table) {
            if (!Schema::hasColumn('keranjangs', 'user_id'))
                $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            if (!Schema::hasColumn('keranjangs', 'produk_id'))
                $table->foreignId('produk_id')->constrained('produks')->cascadeOnDelete();
            if (!Schema::hasColumn('keranjangs', 'jumlah'))
                $table->unsignedInteger('jumlah')->default(1);
            if (!Schema::hasColumn('keranjangs', 'catatan'))
                $table->string('catatan')->nullable();
        });

        // RETURS
        Schema::table('returs', function (Blueprint $table) {
            if (!Schema::hasColumn('returs', 'pesanan_id'))
                $table->foreignId('pesanan_id')->constrained('pesanans')->cascadeOnDelete();
            if (!Schema::hasColumn('returs', 'user_id'))
                $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            if (!Schema::hasColumn('returs', 'toko_id'))
                $table->foreignId('toko_id')->constrained('tokos')->cascadeOnDelete();
            if (!Schema::hasColumn('returs', 'alasan'))
                $table->text('alasan')->nullable();
            if (!Schema::hasColumn('returs', 'status'))
                $table->string('status')->default('menunggu');
            if (!Schema::hasColumn('returs', 'foto'))
                $table->string('foto')->nullable();
            if (!Schema::hasColumn('returs', 'catatan_admin'))
                $table->text('catatan_admin')->nullable();
            if (!Schema::hasColumn('returs', 'deleted_at'))
                $table->softDeletes();
        });

        // VOUCHERS
        Schema::table('vouchers', function (Blueprint $table) {
            if (!Schema::hasColumn('vouchers', 'toko_id'))
                $table->foreignId('toko_id')->nullable()->constrained('tokos')->nullOnDelete();
            if (!Schema::hasColumn('vouchers', 'kode'))
                $table->string('kode')->unique()->nullable();
            if (!Schema::hasColumn('vouchers', 'nama'))
                $table->string('nama')->nullable();
            if (!Schema::hasColumn('vouchers', 'tipe'))
                $table->string('tipe')->default('persen');
            if (!Schema::hasColumn('vouchers', 'nilai'))
                $table->decimal('nilai', 12, 2)->default(0);
            if (!Schema::hasColumn('vouchers', 'min_belanja'))
                $table->decimal('min_belanja', 12, 2)->default(0);
            if (!Schema::hasColumn('vouchers', 'maks_diskon'))
                $table->decimal('maks_diskon', 12, 2)->nullable();
            if (!Schema::hasColumn('vouchers', 'kuota'))
                $table->unsignedInteger('kuota')->default(1);
            if (!Schema::hasColumn('vouchers', 'terpakai'))
                $table->unsignedInteger('terpakai')->default(0);
            if (!Schema::hasColumn('vouchers', 'berlaku_mulai'))
                $table->date('berlaku_mulai')->nullable();
            if (!Schema::hasColumn('vouchers', 'berlaku_sampai'))
                $table->date('berlaku_sampai')->nullable();
            if (!Schema::hasColumn('vouchers', 'status'))
                $table->string('status')->default('aktif');
            if (!Schema::hasColumn('vouchers', 'deleted_at'))
                $table->softDeletes();
        });

        // PROMOS
        Schema::table('promos', function (Blueprint $table) {
            if (!Schema::hasColumn('promos', 'toko_id'))
                $table->foreignId('toko_id')->nullable()->constrained('tokos')->nullOnDelete();
            if (!Schema::hasColumn('promos', 'produk_id'))
                $table->foreignId('produk_id')->nullable()->constrained('produks')->nullOnDelete();
            if (!Schema::hasColumn('promos', 'nama'))
                $table->string('nama')->nullable();
            if (!Schema::hasColumn('promos', 'tipe'))
                $table->string('tipe')->default('diskon');
            if (!Schema::hasColumn('promos', 'nilai'))
                $table->decimal('nilai', 12, 2)->default(0);
            if (!Schema::hasColumn('promos', 'berlaku_mulai'))
                $table->date('berlaku_mulai')->nullable();
            if (!Schema::hasColumn('promos', 'berlaku_sampai'))
                $table->date('berlaku_sampai')->nullable();
            if (!Schema::hasColumn('promos', 'status'))
                $table->string('status')->default('aktif');
            if (!Schema::hasColumn('promos', 'deleted_at'))
                $table->softDeletes();
        });

        // POINS
        Schema::table('poins', function (Blueprint $table) {
            if (!Schema::hasColumn('poins', 'user_id'))
                $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            if (!Schema::hasColumn('poins', 'jumlah'))
                $table->integer('jumlah')->default(0);
            if (!Schema::hasColumn('poins', 'tipe'))
                $table->string('tipe')->default('masuk');
            if (!Schema::hasColumn('poins', 'keterangan'))
                $table->string('keterangan')->nullable();
            if (!Schema::hasColumn('poins', 'referensi_id'))
                $table->unsignedBigInteger('referensi_id')->nullable();
            if (!Schema::hasColumn('poins', 'referensi_tipe'))
                $table->string('referensi_tipe')->nullable();
        });

        // ALAMATS
        Schema::table('alamats', function (Blueprint $table) {
            if (!Schema::hasColumn('alamats', 'user_id'))
                $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            if (!Schema::hasColumn('alamats', 'label'))
                $table->string('label')->nullable();
            if (!Schema::hasColumn('alamats', 'nama_penerima'))
                $table->string('nama_penerima')->nullable();
            if (!Schema::hasColumn('alamats', 'no_hp'))
                $table->string('no_hp', 20)->nullable();
            if (!Schema::hasColumn('alamats', 'provinsi'))
                $table->string('provinsi')->nullable();
            if (!Schema::hasColumn('alamats', 'kota'))
                $table->string('kota')->nullable();
            if (!Schema::hasColumn('alamats', 'kecamatan'))
                $table->string('kecamatan')->nullable();
            if (!Schema::hasColumn('alamats', 'alamat_lengkap'))
                $table->text('alamat_lengkap')->nullable();
            if (!Schema::hasColumn('alamats', 'kode_pos'))
                $table->string('kode_pos', 10)->nullable();
            if (!Schema::hasColumn('alamats', 'is_utama'))
                $table->boolean('is_utama')->default(false);
        });
    }

    public function down(): void
    {
        // Kosongkan atau isi sesuai kebutuhan rollback
    }
};