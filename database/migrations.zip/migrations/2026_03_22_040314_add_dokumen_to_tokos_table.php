<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
   public function up(): void
{
    Schema::table('tokos', function (Blueprint $table) {
        $table->string('nib')->nullable()->after('banner');
        $table->string('no_sku')->nullable()->after('nib');
        $table->string('foto_ktp')->nullable()->after('no_sku');
        $table->string('foto_usaha')->nullable()->after('foto_ktp');
        $table->string('foto_produk_sample')->nullable()->after('foto_usaha');
        $table->text('catatan_dinas')->nullable()->after('catatan_admin');
    });
}

public function down(): void
{
    Schema::table('tokos', function (Blueprint $table) {
        $table->dropColumn(['nib','no_sku','foto_ktp','foto_usaha','foto_produk_sample','catatan_dinas']);
    });
}
};
