<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
{
    Schema::table('ulasans', function (Blueprint $table) {
        $table->foreignId('user_id')->constrained()->cascadeOnDelete();
        $table->foreignId('produk_id')->constrained()->cascadeOnDelete();
        $table->foreignId('pesanan_id')->nullable()->constrained()->nullOnDelete();
        $table->tinyInteger('rating')->default(5); // 1-5
        $table->text('komentar')->nullable();
        $table->string('foto')->nullable();
        $table->text('balasan')->nullable();
        $table->timestamp('dibalas_at')->nullable();
    });
}

public function down(): void
{
    Schema::table('ulasans', function (Blueprint $table) {
        $table->dropColumn(['user_id', 'produk_id', 'pesanan_id', 'rating', 'komentar', 'foto', 'balasan', 'dibalas_at']);
    });
}
};
