<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
{
    Schema::table('users', function (Blueprint $table) {
        $table->date('tanggal_lahir')->nullable()->after('jenis_kelamin');
        $table->string('kota')->nullable()->after('tanggal_lahir');
        $table->string('kecamatan')->nullable()->after('kota');
        $table->string('foto_profil')->nullable()->after('kecamatan');
    });
}

public function down(): void
{
    Schema::table('users', function (Blueprint $table) {
        $table->dropColumn(['tanggal_lahir', 'kota', 'kecamatan', 'foto_profil']);
    });
}
};
