<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
{
    Schema::table('tokos', function (Blueprint $table) {
        $table->string('no_sertifikat')->nullable()->after('kadaluarsa_sertifikat');
        $table->string('nama_kepala_dinas')->nullable()->after('no_sertifikat');
        $table->string('jabatan_kepala_dinas')->nullable()->after('nama_kepala_dinas');
    });
}

public function down(): void
{
    Schema::table('tokos', function (Blueprint $table) {
        $table->dropColumn(['no_sertifikat','nama_kepala_dinas','jabatan_kepala_dinas']);
    });
}
};
