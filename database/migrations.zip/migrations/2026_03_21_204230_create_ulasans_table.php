<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
   public function up(): void
{
    if (!Schema::hasTable('ulasans')) {
        Schema::create('ulasans', function (Blueprint $table) {
            $table->id();
            $table->foreignId('produk_id')->constrained('produks')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('pesanan_id')->nullable()->constrained('pesanans')->nullOnDelete();
            $table->tinyInteger('rating')->default(5);
            $table->text('komentar')->nullable();
            $table->text('balasan')->nullable();
            $table->boolean('dibalas')->default(false);
            $table->timestamp('dibalas_at')->nullable();
            $table->timestamps();
        });
    }
}
};
