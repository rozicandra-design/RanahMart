<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tokos', function (Blueprint $table) {
            if (!Schema::hasColumn('tokos', 'no_hp')) {
                $table->string('no_hp', 20)->nullable()->after('alamat_lengkap');
            }
            if (!Schema::hasColumn('tokos', 'jam_operasional')) {
                $table->string('jam_operasional')->nullable()->after('no_hp');
            }
            if (!Schema::hasColumn('tokos', 'banner')) {
                $table->string('banner')->nullable()->after('logo');
            }
        });
    }

    public function down(): void
    {
        Schema::table('tokos', function (Blueprint $table) {
            if (Schema::hasColumn('tokos', 'no_hp')) {
                $table->dropColumn('no_hp');
            }
            if (Schema::hasColumn('tokos', 'jam_operasional')) {
                $table->dropColumn('jam_operasional');
            }
            if (Schema::hasColumn('tokos', 'banner')) {
                $table->dropColumn('banner');
            }
        });
    }
};