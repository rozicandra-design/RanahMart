<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tokos', function (Blueprint $table) {
            if (!Schema::hasColumn('tokos', 'alamat_lengkap')) {
                $table->string('alamat_lengkap')->nullable()->after('kecamatan');
            }
        });
    }

    public function down(): void
    {
        Schema::table('tokos', function (Blueprint $table) {
            if (Schema::hasColumn('tokos', 'alamat_lengkap')) {
                $table->dropColumn('alamat_lengkap');
            }
        });
    }
};