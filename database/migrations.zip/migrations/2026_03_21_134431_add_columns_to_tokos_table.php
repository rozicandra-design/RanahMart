<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
{
    Schema::table('tokos', function (Blueprint $table) {
        $table->foreignId('user_id')->constrained()->cascadeOnDelete();
        $table->string('nama');
        $table->string('slug')->unique();
        $table->text('deskripsi')->nullable();
        $table->string('foto')->nullable();
        $table->string('kategori')->nullable();
        $table->string('kecamatan')->nullable();
        $table->text('alamat')->nullable();
        $table->string('no_hp')->nullable();
        $table->softDeletes();
    });
}
};
