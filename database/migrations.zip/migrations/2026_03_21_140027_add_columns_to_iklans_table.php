<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
{
    Schema::table('iklans', function (Blueprint $table) {
        $table->string('status')->default('menunggu')->after('id');
        $table->string('paket')->nullable()->after('status');
        $table->decimal('biaya', 15, 2)->default(0)->after('paket');
        $table->string('posisi')->nullable()->after('biaya');
        $table->string('judul')->nullable()->after('posisi');
        $table->text('catatan_pengaju')->nullable()->after('judul');
        $table->text('catatan_admin')->nullable()->after('catatan_pengaju');
        $table->unsignedBigInteger('toko_id')->nullable()->after('catatan_admin');
        $table->date('tanggal_mulai')->nullable()->after('toko_id');
        $table->date('tanggal_selesai')->nullable()->after('tanggal_mulai');
        $table->integer('total_tayangan')->default(0)->after('tanggal_selesai');
        $table->integer('total_klik')->default(0)->after('total_tayangan');
    });
}

public function down(): void
{
    Schema::table('iklans', function (Blueprint $table) {
        $table->dropColumn([
            'status', 'paket', 'biaya', 'posisi', 'judul',
            'catatan_pengaju', 'catatan_admin', 'toko_id',
            'tanggal_mulai', 'tanggal_selesai', 'total_tayangan', 'total_klik',
        ]);
    });
}
};
