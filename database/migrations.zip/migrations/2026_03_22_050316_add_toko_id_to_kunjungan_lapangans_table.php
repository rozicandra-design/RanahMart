<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
{
    Schema::table('kunjungan_lapangans', function (Blueprint $table) {
        $table->foreignId('toko_id')->after('id')->constrained()->cascadeOnDelete();
        $table->foreignId('user_id')->after('toko_id')->constrained()->cascadeOnDelete();
        $table->date('tanggal_kunjungan')->after('user_id');
        $table->text('catatan')->nullable()->after('tanggal_kunjungan');
        $table->text('hasil_kunjungan')->nullable()->after('catatan');
        $table->string('status')->default('dijadwalkan')->after('hasil_kunjungan');
    });
}

public function down(): void
{
    Schema::table('kunjungan_lapangans', function (Blueprint $table) {
        $table->dropForeign(['toko_id']);
        $table->dropForeign(['user_id']);
        $table->dropColumn(['toko_id', 'user_id', 'tanggal_kunjungan', 'catatan', 'hasil_kunjungan', 'status']);
    });
}
};
